console.log("Here!");
// let newDiv = document.getElementsByClassName(
//   "public-DraftStyleDefault-block public-DraftStyleDefault-ltr"
// )[0];

let sperrowIcon = document.createElement("img");
sperrowIcon.src = "https://i.ibb.co/cLfVSR6/icon.png";

let sperrowIconContainer = document.createElement("div");
sperrowIconContainer.id = "sperrowIcon";
sperrowIconContainer.style = "cursor:pointer";

sperrowIconContainer.appendChild(sperrowIcon);

document
  .getElementsByClassName(
    "css-1dbjc4n r-1awozwy r-18u37iz r-1s2bzr4"
  )[0]
  .appendChild(sperrowIconContainer);

console.log("isSuccess??");

document.getElementById("sperrowIcon").onclick = function () {
  console.log("wut?");
  let newDiv = document.getElementsByClassName(
    "public-DraftStyleDefault-block public-DraftStyleDefault-ltr"
  )[0];
  let spanElement = newDiv.childNodes[0];
  const userText = spanElement.textContent;
  //   console.log(spanElement.textContent);
  chrome.storage.local.set({ userTweet: userText });
  chrome.runtime.sendMessage({ message: "tweet received" });
};

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log(request, "received");
});

// let spanElement = newDiv.childNodes[0];

// console.log(spanElement.textContent);
